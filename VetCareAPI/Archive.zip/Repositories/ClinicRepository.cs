using Microsoft.EntityFrameworkCore;
using VetCareAPI.Data;
using VetCareAPI.Models;

namespace VetCareAPI.Repositories;

public class ClinicRepository
{
    private readonly ApplicationDbContext _db;
    public ClinicRepository(ApplicationDbContext db)
    {
        _db = db;
    }

    public Task<List<Clinic>> GetAllClinicsAsync()
    {
        return _db.Clinics.AsNoTracking().ToListAsync();
    }

    public Task<Clinic?> GetClinicByIdAsync(Guid id)
    {
        return _db.Clinics.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
    }
    
    public Task<bool> ExistsAsync(Guid id)
    {
        return _db.Clinics.AnyAsync(c => c.Id == id);
    }

    public async Task<Clinic> AddClinicAsync(Clinic clinic)
    {
        _db.Clinics.Add(clinic);
        await _db.SaveChangesAsync();
        return clinic;
    }

    public async Task<bool> UpdateClinicAsync(Clinic entity)
    {
        _db.Clinics.Update(entity);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteClinicAsync(Guid id)
    {
        var tracked = await _db.Clinics.FirstOrDefaultAsync(c => c.Id == id);
        if (tracked is null) return false;
        _db.Clinics.Remove(tracked);
        await _db.SaveChangesAsync();
        return true;
    }

    public Task<List<Visit>> GetVisitsAsync(Guid clinicId)
    {
        return _db.Visits.AsNoTracking().Where(v => v.ClinicId == clinicId).ToListAsync();
    }
}