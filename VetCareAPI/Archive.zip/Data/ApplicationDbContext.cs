// Data/ApplicationDbContext.cs
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using VetCareAPI.Models;

namespace VetCareAPI.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Clinic> Clinics => Set<Clinic>();
    public DbSet<AppUser> Users   => Set<AppUser>();
    public DbSet<Pet> Pets        => Set<Pet>();
    public DbSet<Visit> Visits    => Set<Visit>();

    protected override void OnModelCreating(ModelBuilder model)
    {
        base.OnModelCreating(model);

        model.Entity<Pet>()
            .HasOne(p => p.User)
            .WithMany(u => u.Pets)
            .HasForeignKey(p => p.UserId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Visit>()
            .HasOne(v => v.Clinic)
            .WithMany(c => c.Visits)
            .HasForeignKey(v => v.ClinicId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Visit>()
            .HasOne(v => v.Pet)
            .WithMany(p => p.Visits)
            .HasForeignKey(v => v.PetId)
            .OnDelete(DeleteBehavior.Cascade);

        var utc = new ValueConverter<DateTime, DateTime>(
            toProvider   => toProvider.Kind == DateTimeKind.Utc ? toProvider : toProvider.ToUniversalTime(),
            fromProvider => DateTime.SpecifyKind(fromProvider, DateTimeKind.Utc)
        );
        model.Entity<Visit>()
            .Property(v => v.StartsAt)
            .HasColumnType("datetime(6)")
            .HasConversion(utc);

        // Seed deterministic demo data (good for your lab demo)
        var clinic1 = Guid.Parse("11111111-1111-1111-1111-111111111111");
        var user1   = Guid.Parse("22222222-2222-2222-2222-222222222222");
        var pet1    = Guid.Parse("33333333-3333-3333-3333-333333333333");
        var visit1  = Guid.Parse("44444444-4444-4444-4444-444444444444");

        model.Entity<Clinic>().HasData(new Clinic {
            Id = clinic1, Name = "ZooVet Kaunas", City = "Kaunas", Address = "Laisvės al. 1"
        });

        model.Entity<AppUser>().HasData(new AppUser {
            Id = user1, FullName = "Rokas Meškauskas", Email = "rokas@example.com"
        });

        model.Entity<Pet>().HasData(new Pet {
            Id = pet1, Name = "Maksis", Species = "Dog", UserId = user1
        });

        model.Entity<Visit>().HasData(new Visit {
            Id = visit1,
            StartsAt = new DateTime(2025, 10, 12, 08, 30, 00, DateTimeKind.Utc),
            Notes = "Annual check",
            Status = VisitStatus.Scheduled,
            ClinicId = clinic1,
            PetId = pet1
        });
    }
}
