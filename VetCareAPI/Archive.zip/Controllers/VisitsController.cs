using Microsoft.AspNetCore.Mvc;
using VetCareAPI.Models.DTOs.Visits;
using VetCareAPI.Services;

namespace VetCareAPI.Controllers;

[ApiController]
[Route("api/visits")]
[Produces("application/json")]
public class VisitsController : ControllerBase
{
    private readonly VisitService _visitService;
    public VisitsController(VisitService svc) => _visitService = svc;

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var visit = await _visitService.GetAsync(id);
        if (visit is null)
        {
            return NotFound();
        }
        return Ok(visit);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateVisitDto dto)
    {
        if (!ModelState.IsValid) return UnprocessableEntity(ModelState);
        try
        {
            var created = await _visitService.CreateAsync(dto);
            return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
        }
        catch (ArgumentException ex)          { return UnprocessableEntity(new { message = ex.Message }); }
        catch (InvalidOperationException ex)  { return UnprocessableEntity(new { message = ex.Message }); }
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateVisitDto dto)
    {
        if (!ModelState.IsValid) return UnprocessableEntity(ModelState);
        try
        {
            return await _visitService.UpdateAsync(id, dto) ? NoContent() : NotFound();
        }
        catch (ArgumentException ex) { return UnprocessableEntity(new { message = ex.Message }); }
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Cancel(Guid id)
        => await _visitService.CancelAsync(id) ? NoContent() : NotFound();

    [HttpGet("user/{userId:guid}/upcoming")]
    public async Task<IActionResult> UpcomingForUser(Guid userId, [FromQuery] DateTime? fromUtc)
        => Ok(await _visitService.GetUpcomingForUserAsync(userId, fromUtc));

    [HttpGet("user/{userId:guid}/past")]
    public async Task<IActionResult> PastForUser(Guid userId, [FromQuery] DateTime? untilUtc)
        => Ok(await _visitService.GetPastForUserAsync(userId, untilUtc));

    [HttpGet("clinic/{clinicId:guid}")]
    public async Task<IActionResult> ByClinic(Guid clinicId, [FromQuery] DateTime? fromUtc, [FromQuery] DateTime? toUtc)
        => Ok(await _visitService.GetByClinicAsync(clinicId, fromUtc, toUtc));
}
