namespace VetCareAPI.Controllers;

public class AppUserController
{
    
}