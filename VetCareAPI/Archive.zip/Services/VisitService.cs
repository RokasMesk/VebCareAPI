// Services/VisitService.cs
using VetCareAPI.Models;
using VetCareAPI.Models.DTOs.Visits;
using VetCareAPI.Models.Mappings;
using VetCareAPI.Repositories;

namespace VetCareAPI.Services;

public class VisitService
{
    private readonly VisitRepository _visits;
    private readonly ClinicRepository _clinics;
    private readonly PetRepository _pets;
    public VisitService(VisitRepository visits, ClinicRepository clinics, PetRepository pets)
    { _visits = visits; _clinics = clinics; _pets = pets; }

    public async Task<VisitDto> CreateAsync(CreateVisitDto dto)
    {
        if (!await _clinics.ExistsAsync(dto.ClinicId))
            throw new InvalidOperationException("Clinic not found"); // -> 422
        if (await _pets.GetPetById(dto.PetId) is  null)
            throw new InvalidOperationException("Pet not found");    // -> 422
        if (dto.EndsAt <= dto.StartsAt)
            throw new ArgumentException("EndsAt must be after StartsAt");

        var v = dto.ToEntity();
        await _visits.AddAsync(v);
        return v.ToDto();
    }

    // Edit visit
    public async Task<bool> UpdateAsync(Guid id, UpdateVisitDto dto)
    {
        if (dto.EndsAt <= dto.StartsAt)
            throw new ArgumentException("EndsAt must be after StartsAt");

        var v = await _visits.GetVisitById(id);
        if (v is null) return false; // -> 404
        v.Apply(dto);
        return await _visits.UpdateVisitAsync(v);
    }

    // Cancel visit (clinic or user)
    public async Task<bool> CancelAsync(Guid id)
    {
        var v = await _visits.GetVisitById(id);
        if (v is null) return false;
        v.Status = VisitStatus.Cancelled;
        return await _visits.UpdateVisitAsync(v);
    }
    
    public async Task<List<VisitDto>> GetUpcomingForUserAsync(Guid userId, DateTime? fromUtc = null)
    {
        fromUtc ??= DateTime.UtcNow;
        var pets = await _pets.GetPetsByUserIdAsync(userId);
        var petIds = pets.Select(p => p.Id).ToHashSet();
        var all = await _visits.GetUpcomingAsync();
        return all.Where(v => petIds.Contains(v.PetId)).Select(v => v.ToDto()).ToList();
    }

    public async Task<List<VisitDto>> GetPastForUserAsync(Guid userId, DateTime? untilUtc = null)
    {
        untilUtc ??= DateTime.UtcNow;
        var pets = await _pets.GetPetsByUserIdAsync(userId);
        var petIds = pets.Select(p => p.Id).ToHashSet();
        var all = await _visits.GetAllVisitsAsync();
        return all.Where(v => v.StartsAt < untilUtc && petIds.Contains(v.PetId))
                  .OrderByDescending(v => v.StartsAt)
                  .Select(v => v.ToDto()).ToList();
    }

    // Clinic: all visits (calendar/summary)
    public async Task<List<VisitDto>> GetByClinicAsync(Guid clinicId, DateTime? fromUtc = null, DateTime? toUtc = null)
    {
        var list = await _visits.GetByClinicAsync(clinicId);
        if (fromUtc is not null) list = list.Where(v => v.StartsAt >= fromUtc).ToList();
        if (toUtc   is not null) list = list.Where(v => v.StartsAt <= toUtc).ToList();
        return list.Select(v => v.ToDto()).ToList();
    }

    public async Task<VisitDto?> GetAsync(Guid id) =>
        (await _visits.GetVisitById(id))?.ToDto();
}
