using System.Reflection;
using Microsoft.EntityFrameworkCore;
using VetCareAPI.Data;
using VetCareAPI.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddXmlSerializerFormatters();

builder.Services.AddDbContext<ApplicationDbContext>(opt =>
    opt.UseMySql(
        builder.Configuration.GetConnectionString("db"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("db"))
    ));

builder.Services.AddScoped<ClinicRepository>();
builder.Services.AddScoped<AppUserRepository>();
builder.Services.AddScoped<PetRepository>();
builder.Services.AddScoped<VisitRepository>();

// 4) OpenAPI / Swagger (with XML comments if you enable them in csproj -> <GenerateDocumentationFile>true</GenerateDocumentationFile>)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    var xml = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xml);
    if (File.Exists(xmlPath)) c.IncludeXmlComments(xmlPath);
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// app.UseAuthentication();
// app.UseAuthorization();

app.MapControllers();

app.Run();
